-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2021 at 12:47 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `passenger_id` int(11) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `cnic` varchar(30) DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`passenger_id`, `fname`, `lname`, `cnic`, `gender`, `city`, `province`, `email`) VALUES
(1, 'Abdullah', 'Baloch', '35202-123456789', 'M', 'Lahore', 'Punjab', 'abdullahbaloch@gmail.com'),
(2, 'Abdul-Reham', 'Baloch', '35202-123456780', 'M', 'Lahore', 'Punjab', 'rehmanbaloch@gmail.com'),
(3, 'Gohar', 'Hayat', '35202-123456771', 'M', 'Pak-Watan', 'Punjab', 'goharhayat@gmail.com'),
(4, 'Areeb', 'Javaid', '35202-123458888', 'M', 'Swabi', 'KPK', 'areebj@gmail.com'),
(5, 'Arsalan', 'Jondas', '35202-123450000', 'M', 'Lahore', 'Punjab', 'arsalan@gmail.com'),
(6, 'Subhan', 'Jutt', '35202-123451111', 'M', 'Lahore', 'Punjab', 'subhan@gmail.com'),
(7, 'Faizan', 'Sheikh', '35202-123452222', 'M', 'Lahore', 'Punjab', 'faizan@gmail.com'),
(8, 'Dabeer', 'Sheikh', '35202-123453333', 'M', 'Lahore', 'Punjab', 'dabeer@gmail.com'),
(9, 'Talha', 'Ilyas', '35202-123444444', 'M', 'Lahore', 'Punjab', 'chtalha@gmail.com'),
(10, 'Hamza', 'Ilyas', '35202-123444455', 'M', 'Lahore', 'Punjab', 'chtalha@gmail.com'),
(11, 'Habib', 'Waraich', '35202-123666666', 'M', 'Lahore', 'Punjab', 'habib@gmail.com'),
(12, 'Ali', 'Jutt', '35202-123666667', 'M', 'Lahore', 'Punjab', 'ali@gmail.com'),
(13, 'Ali', 'Hassan', '35202-123006667', 'M', 'Lahore', 'Punjab', 'aliH@gmail.com'),
(14, 'Hassan', 'Ali', '35202-003006600', 'M', 'Lahore', 'Punjab', 'hassan@gmail.com'),
(15, 'Shan', 'Mughal', '35202-003006123', 'M', 'Lahore', 'Punjab', 'shanM@gmail.com'),
(16, 'Ibrahim', 'Mughal', '35202-003234123', 'M', 'Lahore', 'Punjab', 'Ibraha@gmail.com'),
(17, 'Haseeb', 'Mughal', '34502-003234123', 'M', 'Gujranawala', 'Punjab', 'hm@gmail.com'),
(18, 'Gulab', 'Khan', '34502-003239090', 'M', 'Peshawar', 'KPK', 'gk@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `fare` int(11) DEFAULT NULL,
  `ticket_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `fare`, `ticket_id`) VALUES
(3, 700, 9),
(4, 1000, 2),
(5, 1500, 8),
(6, 500, 3),
(7, 700, 7),
(8, 1000, 4),
(9, 1500, 6),
(10, 500, 5),
(11, 1500, 6);

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(11) NOT NULL,
  `station_name` varchar(50) DEFAULT NULL,
  `stay` varchar(20) DEFAULT NULL,
  `atime` time DEFAULT NULL,
  `train_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `ticket_id` int(11) NOT NULL,
  `no_of_seats` int(11) DEFAULT NULL,
  `booked_passengers` varchar(50) DEFAULT NULL,
  `passenger_id` int(11) DEFAULT NULL,
  `train_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticket_id`, `no_of_seats`, `booked_passengers`, `passenger_id`, `train_id`) VALUES
(1, 1, 'Abdullah', 1, 1),
(2, 2, 'Abdur-Rehman', 2, 5),
(3, 2, 'Gulab Khan', 18, 5),
(4, 1, 'Ali Hassan', 13, 2),
(5, 1, 'Arsalan Jondas', 5, 5),
(6, 1, 'Talha Ilyas', 9, 5),
(7, 1, 'Hamza Ilyas', 10, 5),
(8, 1, 'Dabeer', 8, 5),
(9, 15, 'Subhan Jutt', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `train_id` int(11) NOT NULL,
  `train_name` varchar(50) DEFAULT NULL,
  `atime` time DEFAULT NULL,
  `dtime` time DEFAULT NULL,
  `tdate` date DEFAULT NULL,
  `departure` varchar(50) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`train_id`, `train_name`, `atime`, `dtime`, `tdate`, `departure`, `destination`) VALUES
(1, 'Shalimaar Express', '09:00:00', '04:00:00', '2021-06-02', 'Lahore', 'Islamabad'),
(2, 'Alama Iqbal Express', '01:15:00', '08:45:00', '2021-06-02', 'Lahore', 'Multan'),
(3, 'Faiz Ahmed Express', '08:00:00', '03:15:00', '2021-06-02', 'Multan', 'Karachi'),
(4, 'Jinnah Express', '12:00:00', '08:15:00', '2021-06-02', 'Islamabad', 'Nosherah'),
(5, 'Khatak Khan Express', '10:00:00', '08:00:00', '2021-06-02', 'Lahore', 'Peshawar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`passenger_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `ticket_id` (`ticket_id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`),
  ADD KEY `train_id` (`train_id`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `passenger_id` (`passenger_id`),
  ADD KEY `train_id` (`train_id`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`train_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `passenger`
--
ALTER TABLE `passenger`
  MODIFY `passenger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `station_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket`
--
ALTER TABLE `ticket`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `train`
--
ALTER TABLE `train`
  MODIFY `train_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `ticket` (`ticket_id`);

--
-- Constraints for table `station`
--
ALTER TABLE `station`
  ADD CONSTRAINT `station_ibfk_1` FOREIGN KEY (`train_id`) REFERENCES `train` (`train_id`);

--
-- Constraints for table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `ticket_ibfk_1` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`),
  ADD CONSTRAINT `ticket_ibfk_2` FOREIGN KEY (`train_id`) REFERENCES `train` (`train_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
