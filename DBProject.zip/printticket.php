<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbproject";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>
<style>

    .bdy{
        background-image:url("1t.jpg");
       background-size:100%;
        color:aliceblue;
    }   
    .txt
    {
        margin-top: 50px;
        font-size:20px;
        border-collapse: collapse;
        color:aliceblue;
        border-color:aliceblue;
    }
</style>
</head>
<body class="bdy">

<h1 align="center">*************Ticket Table Data**********</h1>

<table border="1" align="center" style="line-height:25px;" class="txt">
<tr>
<th>Ticket ID</th>
<th>No. Of Seats</th>
<th>Name</th>
<th>Passenger's ID</th>
<th>Train ID</th>
</tr>
<?php
$sql = "SELECT * FROM ticket";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['ticket_id'];?></td>
<td> <?php  echo $row['no_of_seats'];?></td>
<td> <?php  echo $row['booked_passengers'];?></td>
<td> <?php  echo $row['passenger_id'];?></td>
<td> <?php  echo $row['train_id'];?></td>

</tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>