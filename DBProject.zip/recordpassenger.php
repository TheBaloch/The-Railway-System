<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbproject";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>
<style>

    .bdy{
        background-image:url("3.jpg");
       background-size:100%;
        color:aliceblue;
    }   
    .txt
    {
        font-size:20px;
        border-collapse: collapse;
        color:aliceblue;
        border-color:aliceblue;
    }
</style>
</head>
<body class="bdy">

<h1 align="center">*************Passenger Table Data**********</h1>

<table border="1" align="center" style="line-height:25px;" class="txt">
<tr>
<th>Passenger ID</th>
<th>First Name</th>
<th>Last Name</th>
<th>CNIC</th>
<th>Gender</th>
<th>City</th>
<th>Province</th>
<th>Email</th>
</tr>
<?php
$sql = "SELECT * FROM passenger";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['passenger_id'];?></td>
<td> <?php  echo $row['fname'];?></td>
<td> <?php  echo $row['lname'];?></td>
<td> <?php  echo $row['cnic'];?></td>
<td> <?php  echo $row['gender'];?></td>
<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['province'];?></td>
<td> <?php  echo $row['email'];?></td>

<td><a href="editpassenger.php?edit_id=<?php echo $row['passenger_id']; ?>" alt="edit" >Update Record</a></td>
 
</tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>