<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbproject";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>
<style>

    .bdy{
        background-image:url("1tr.jpg");
       background-size:100%;
        color:aliceblue;
    }   
    .txt
    {
        font-size:20px;
        border-collapse: collapse;
        color:aliceblue;
        border-color:aliceblue;
    }
</style>
</head>
<body class="bdy">

<h1 align="center">*************Train Table Data**********</h1>

<table border="1" align="center" style="line-height:25px;" class="txt">
<tr>
<th>Train ID</th>
<th>Train Name</th>
<th>Departure Time</th>
<th>Arival Time</th>
<th>Departure Location</th>
<th>Destination</th>
</tr>
<?php
$sql = "SELECT * FROM train";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['train_id'];?></td>
<td> <?php  echo $row['train_name'];?></td>
<td> <?php  echo $row['dtime'];?></td>
<td> <?php  echo $row['atime'];?></td>
<td> <?php  echo $row['departure'];?></td>
<td> <?php  echo $row['destination'];?></td>
</tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>